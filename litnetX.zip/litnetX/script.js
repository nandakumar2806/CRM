// ========== DATA STORAGE (localStorage) ==========
const STORAGE_KEYS = {
  USERS: 'crm_users',
  CONTACTS: 'crm_contacts',
  COMPANIES: 'crm_companies',
  DEALS: 'crm_deals',
  TASKS: 'crm_tasks',
  ACTIVITIES: 'crm_activities',
  CURRENT_USER: 'crm_current_user'
};

// Initialize default data
function initializeData() {
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    const defaultUsers = [
      { id: '1', username: 'admin', password: 'admin123', name: 'Admin User', email: 'admin@crm.com', role: 'admin', createdAt: new Date().toISOString() }
    ];
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.CONTACTS)) {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify([]));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.COMPANIES)) {
    localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify([]));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.DEALS)) {
    localStorage.setItem(STORAGE_KEYS.DEALS, JSON.stringify([]));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.TASKS)) {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify([]));
  }
  
  if (!localStorage.getItem(STORAGE_KEYS.ACTIVITIES)) {
    localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify([]));
  }
}

// Helper functions
function getData(key) {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function setData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// ========== GLOBAL VARIABLES ==========
let currentUser = null;

// ========== AUTHENTICATION ==========
document.addEventListener('DOMContentLoaded', function() {
  initializeData();
  
  // Check if user is already logged in
  const savedUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  if (savedUser) {
    currentUser = JSON.parse(savedUser);
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('mainApp').style.display = 'flex';
    initializeApp();
    return;
  }

  // Login form
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const username = document.getElementById('loginUser').value.trim();
      const password = document.getElementById('loginPass').value.trim();
      const users = getData(STORAGE_KEYS.USERS);
      const user = users.find(u => (u.username === username || u.email === username) && u.password === password);
      
      if (user) {
        currentUser = { id: user.id, username: user.username, name: user.name, email: user.email, role: user.role };
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('mainApp').style.display = 'flex';
        initializeApp();
      } else {
        document.getElementById('loginMsg').textContent = 'Invalid username or password';
      }
    });
  }

  // Signup form
  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    signupForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('signupName').value.trim();
      const email = document.getElementById('signupEmail').value.trim();
      const username = document.getElementById('signupUser').value.trim();
      const password = document.getElementById('signupPass').value.trim();
      
      const users = getData(STORAGE_KEYS.USERS);
      if (users.find(u => u.username === username || u.email === email)) {
        document.getElementById('signupMsg').textContent = 'Username or email already exists';
        return;
      }
      
      const newUser = {
        id: generateId(),
        username,
        password,
        name,
        email,
        role: 'user',
        createdAt: new Date().toISOString()
      };
      
      users.push(newUser);
      setData(STORAGE_KEYS.USERS, users);
      
      currentUser = { id: newUser.id, username: newUser.username, name: newUser.name, email: newUser.email, role: newUser.role };
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
      document.getElementById('loginScreen').style.display = 'none';
      document.getElementById('mainApp').style.display = 'flex';
      initializeApp();
    });
  }
});

window.showSignup = function() {
  document.querySelector('.login-box').style.display = 'none';
  document.getElementById('signupBox').style.display = 'block';
};

window.showLogin = function() {
  document.getElementById('signupBox').style.display = 'none';
  document.querySelector('.login-box').style.display = 'block';
};

window.logout = function() {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  currentUser = null;
  document.getElementById('mainApp').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  document.querySelector('.login-box').style.display = 'block';
  document.getElementById('signupBox').style.display = 'none';
};

// ========== INITIALIZE APP ==========
function initializeApp() {
  if (currentUser) {
    document.getElementById('sidebarUserName').textContent = currentUser.name;
    document.getElementById('sidebarUserEmail').textContent = currentUser.email;
  }
  showSection('dashboard');
  loadDashboard();
}

// ========== NAVIGATION ==========
window.showSection = function(section) {
  document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  
  document.getElementById(section).classList.add('active');
  event?.target?.closest('.nav-item')?.classList.add('active');

  switch(section) {
    case 'dashboard':
      loadDashboard();
      break;
    case 'contacts':
      loadContacts();
      break;
    case 'companies':
      loadCompanies();
      break;
    case 'deals':
      loadDeals();
      break;
    case 'tasks':
      loadTasks();
      break;
    case 'activities':
      loadActivities();
      break;
    case 'reports':
      loadReports();
      break;
  }
};

// ========== DASHBOARD ==========
function loadDashboard() {
  const contacts = getData(STORAGE_KEYS.CONTACTS);
  const companies = getData(STORAGE_KEYS.COMPANIES);
  const deals = getData(STORAGE_KEYS.DEALS);
  const tasks = getData(STORAGE_KEYS.TASKS);
  
  const totalRevenue = deals.reduce((sum, deal) => sum + (parseFloat(deal.value) || 0), 0);
  const wonDeals = deals.filter(d => d.stage === 'Won').length;
  const pendingTasks = tasks.filter(t => t.status !== 'Completed').length;
  const conversionRate = deals.length > 0 ? ((wonDeals / deals.length) * 100).toFixed(1) : 0;

  const statsGrid = document.getElementById('dashboardStats');
  statsGrid.innerHTML = `
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Total Contacts</span>
        <div class="stat-card-icon" style="background: #dbeafe; color: #2563eb;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
            <circle cx="9" cy="7" r="4"></circle>
            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">${contacts.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Total Companies</span>
        <div class="stat-card-icon" style="background: #d1fae5; color: #10b981;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
            <circle cx="12" cy="10" r="3"></circle>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">${companies.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Total Deals</span>
        <div class="stat-card-icon" style="background: #fef3c7; color: #f59e0b;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
            <circle cx="8.5" cy="7" r="4"></circle>
            <path d="M20 8v6M23 11h-6"></path>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">${deals.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Total Revenue</span>
        <div class="stat-card-icon" style="background: #fce7f3; color: #ec4899;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="1" x2="12" y2="23"></line>
            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">$${formatNumber(totalRevenue)}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Won Deals</span>
        <div class="stat-card-icon" style="background: #d1fae5; color: #10b981;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">${wonDeals}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card-header">
        <span class="stat-card-title">Conversion Rate</span>
        <div class="stat-card-icon" style="background: #e0e7ff; color: #6366f1;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="20" x2="18" y2="10"></line>
            <line x1="12" y1="20" x2="12" y2="4"></line>
            <line x1="6" y1="20" x2="6" y2="14"></line>
          </svg>
        </div>
      </div>
      <div class="stat-card-value">${conversionRate}%</div>
    </div>
  `;

  // Recent activities
  const activities = getData(STORAGE_KEYS.ACTIVITIES);
  const recentActivities = activities.slice(0, 5);
  document.getElementById('recentActivities').innerHTML = recentActivities.length > 0
    ? recentActivities.map(a => `
        <div class="activity-item">
          <div class="activity-icon" style="background: #dbeafe; color: #2563eb;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
            </svg>
          </div>
          <div class="activity-content">
            <div class="activity-header">
              <span class="activity-subject">${a.subject}</span>
              <span class="activity-time">${formatTimeAgo(a.createdAt)}</span>
            </div>
            <div class="activity-description">${a.description || ''}</div>
          </div>
        </div>
      `).join('')
    : '<div class="empty-state">No recent activities</div>';

  // Upcoming tasks
  const upcoming = tasks.filter(t => t.status !== 'Completed').slice(0, 5);
  document.getElementById('upcomingTasks').innerHTML = upcoming.length > 0
    ? upcoming.map(t => `
        <div class="task-item">
          <input type="checkbox" class="task-checkbox" onchange="toggleTaskStatus('${t.id}')">
          <div class="task-content">
            <div class="task-title">${t.title}</div>
            <div class="task-meta">
              <span class="priority-badge priority-${(t.priority || 'medium').toLowerCase()}">${t.priority || 'Medium'}</span>
              ${t.dueDate ? `<span>Due: ${formatDate(t.dueDate)}</span>` : ''}
            </div>
          </div>
        </div>
      `).join('')
    : '<div class="empty-state">No upcoming tasks</div>';

  // Deal pipeline
  const pipelineData = deals.reduce((acc, deal) => {
    acc[deal.stage] = (acc[deal.stage] || 0) + parseFloat(deal.value || 0);
    return acc;
  }, {});

  const stages = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Won'];
  const maxValue = Math.max(...Object.values(pipelineData), 1);
  document.getElementById('dealPipeline').innerHTML = stages.map(stage => `
    <div style="margin-bottom: 16px;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
        <span style="font-size: 12px; color: #64748b;">${stage}</span>
        <span style="font-size: 12px; font-weight: 600;">$${formatNumber(pipelineData[stage] || 0)}</span>
      </div>
      <div style="height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
        <div style="height: 100%; width: ${((pipelineData[stage] || 0) / maxValue) * 100}%; background: #2563eb; transition: width 0.3s;"></div>
      </div>
    </div>
  `).join('') || '<div class="empty-state">No deals in pipeline</div>';
}

window.refreshDashboard = function() {
  loadDashboard();
};

// ========== CONTACTS ==========
function loadContacts() {
  const contacts = getData(STORAGE_KEYS.CONTACTS);
  const tbody = document.getElementById('contactsTableBody');
  tbody.innerHTML = contacts.length > 0
    ? contacts.map(contact => `
        <tr>
          <td>${contact.firstName || ''} ${contact.lastName || ''}</td>
          <td>${contact.email || ''}</td>
          <td>${contact.phone || '-'}</td>
          <td>${contact.company || '-'}</td>
          <td><span class="status-badge status-${(contact.status || 'active').toLowerCase()}">${contact.status || 'Active'}</span></td>
          <td>
            <div class="action-buttons">
              <button class="btn-icon btn-edit" onclick="editContact('${contact.id}')" title="Edit">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                </svg>
              </button>
              <button class="btn-icon btn-delete" onclick="deleteContact('${contact.id}')" title="Delete">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3 6 5 6 21 6"></polyline>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('')
    : '<tr><td colspan="6" class="empty-state">No contacts found</td></tr>';
}

window.openContactModal = function(contactId = null) {
  const modal = document.getElementById('contactModal');
  const form = document.getElementById('contactForm');
  const title = document.getElementById('contactModalTitle');

  if (contactId) {
    title.textContent = 'Edit Contact';
    const contacts = getData(STORAGE_KEYS.CONTACTS);
    const contact = contacts.find(c => c.id === contactId);
    if (contact) {
      document.getElementById('contactFirstName').value = contact.firstName || '';
      document.getElementById('contactLastName').value = contact.lastName || '';
      document.getElementById('contactEmail').value = contact.email || '';
      document.getElementById('contactPhone').value = contact.phone || '';
      document.getElementById('contactCompany').value = contact.company || '';
      document.getElementById('contactJobTitle').value = contact.jobTitle || '';
      document.getElementById('contactStatus').value = contact.status || 'Active';
      form.dataset.contactId = contactId;
    }
  } else {
    title.textContent = 'Add Contact';
    form.reset();
    delete form.dataset.contactId;
  }

  modal.classList.add('active');
};

window.saveContact = function(e) {
  e.preventDefault();
  const form = document.getElementById('contactForm');
  const contactId = form.dataset.contactId;
  const contacts = getData(STORAGE_KEYS.CONTACTS);

  const data = {
    firstName: document.getElementById('contactFirstName').value,
    lastName: document.getElementById('contactLastName').value,
    email: document.getElementById('contactEmail').value,
    phone: document.getElementById('contactPhone').value,
    company: document.getElementById('contactCompany').value,
    jobTitle: document.getElementById('contactJobTitle').value,
    status: document.getElementById('contactStatus').value
  };

  if (contactId) {
    const index = contacts.findIndex(c => c.id === contactId);
    if (index !== -1) {
      contacts[index] = { ...contacts[index], ...data, updatedAt: new Date().toISOString() };
    }
  } else {
    contacts.push({
      id: generateId(),
      ...data,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  setData(STORAGE_KEYS.CONTACTS, contacts);
  closeModal('contactModal');
  loadContacts();
  if (document.getElementById('dashboard').classList.contains('active')) {
    loadDashboard();
  }
};

window.editContact = function(id) {
  openContactModal(id);
};

window.deleteContact = function(id) {
  if (confirm('Are you sure you want to delete this contact?')) {
    const contacts = getData(STORAGE_KEYS.CONTACTS);
    const filtered = contacts.filter(c => c.id !== id);
    setData(STORAGE_KEYS.CONTACTS, filtered);
    loadContacts();
    if (document.getElementById('dashboard').classList.contains('active')) {
      loadDashboard();
    }
  }
};

window.filterContacts = function() {
  const search = document.getElementById('contactSearch').value.toLowerCase();
  const rows = document.querySelectorAll('#contactsTableBody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(search) ? '' : 'none';
  });
};

// ========== COMPANIES ==========
function loadCompanies() {
  const companies = getData(STORAGE_KEYS.COMPANIES);
  const tbody = document.getElementById('companiesTableBody');
  tbody.innerHTML = companies.length > 0
    ? companies.map(company => `
        <tr>
          <td>${company.name || ''}</td>
          <td>${company.industry || '-'}</td>
          <td>${company.website ? `<a href="${company.website}" target="_blank">${company.website}</a>` : '-'}</td>
          <td>${company.employees || '-'}</td>
          <td>${company.revenue ? `$${formatNumber(company.revenue)}` : '-'}</td>
          <td>
            <div class="action-buttons">
              <button class="btn-icon btn-edit" onclick="editCompany('${company.id}')" title="Edit">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                </svg>
              </button>
              <button class="btn-icon btn-delete" onclick="deleteCompany('${company.id}')" title="Delete">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3 6 5 6 21 6"></polyline>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('')
    : '<tr><td colspan="6" class="empty-state">No companies found</td></tr>';
}

window.openCompanyModal = function(companyId = null) {
  const modal = document.getElementById('companyModal');
  const form = document.getElementById('companyForm');
  const title = document.getElementById('companyModalTitle');

  if (companyId) {
    title.textContent = 'Edit Company';
    const companies = getData(STORAGE_KEYS.COMPANIES);
    const company = companies.find(c => c.id === companyId);
    if (company) {
      document.getElementById('companyName').value = company.name || '';
      document.getElementById('companyIndustry').value = company.industry || '';
      document.getElementById('companyWebsite').value = company.website || '';
      document.getElementById('companyPhone').value = company.phone || '';
      document.getElementById('companyAddress').value = company.address || '';
      document.getElementById('companyEmployees').value = company.employees || '';
      document.getElementById('companyRevenue').value = company.revenue || '';
      form.dataset.companyId = companyId;
    }
  } else {
    title.textContent = 'Add Company';
    form.reset();
    delete form.dataset.companyId;
  }

  modal.classList.add('active');
};

window.saveCompany = function(e) {
  e.preventDefault();
  const form = document.getElementById('companyForm');
  const companyId = form.dataset.companyId;
  const companies = getData(STORAGE_KEYS.COMPANIES);

  const data = {
    name: document.getElementById('companyName').value,
    industry: document.getElementById('companyIndustry').value,
    website: document.getElementById('companyWebsite').value,
    phone: document.getElementById('companyPhone').value,
    address: document.getElementById('companyAddress').value,
    employees: document.getElementById('companyEmployees').value,
    revenue: document.getElementById('companyRevenue').value
  };

  if (companyId) {
    const index = companies.findIndex(c => c.id === companyId);
    if (index !== -1) {
      companies[index] = { ...companies[index], ...data, updatedAt: new Date().toISOString() };
    }
  } else {
    companies.push({
      id: generateId(),
      ...data,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  setData(STORAGE_KEYS.COMPANIES, companies);
  closeModal('companyModal');
  loadCompanies();
  if (document.getElementById('dashboard').classList.contains('active')) {
    loadDashboard();
  }
};

window.editCompany = function(id) {
  openCompanyModal(id);
};

window.deleteCompany = function(id) {
  if (confirm('Are you sure you want to delete this company?')) {
    const companies = getData(STORAGE_KEYS.COMPANIES);
    const filtered = companies.filter(c => c.id !== id);
    setData(STORAGE_KEYS.COMPANIES, filtered);
    loadCompanies();
    if (document.getElementById('dashboard').classList.contains('active')) {
      loadDashboard();
    }
  }
};

window.filterCompanies = function() {
  const search = document.getElementById('companySearch').value.toLowerCase();
  const rows = document.querySelectorAll('#companiesTableBody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(search) ? '' : 'none';
  });
};

// ========== DEALS ==========
function loadDeals() {
  const deals = getData(STORAGE_KEYS.DEALS);
  const stages = ['Prospecting', 'Qualification', 'Proposal', 'Negotiation', 'Won', 'Lost'];
  
  stages.forEach(stage => {
    const stageDeals = deals.filter(d => d.stage === stage);
    document.getElementById(`count-${stage.toLowerCase()}`).textContent = stageDeals.length;
    document.getElementById(`deals-${stage.toLowerCase()}`).innerHTML = stageDeals.map(deal => `
      <div class="deal-card" onclick="editDeal('${deal.id}')">
        <div class="deal-card-title">${deal.name || 'Untitled Deal'}</div>
        <div class="deal-card-company">${deal.companyName || 'No Company'}</div>
        <div class="deal-card-value">$${formatNumber(deal.value || 0)}</div>
      </div>
    `).join('');
  });
}

window.openDealModal = function(dealId = null) {
  const modal = document.getElementById('dealModal');
  const form = document.getElementById('dealForm');
  const title = document.getElementById('dealModalTitle');

  const companies = getData(STORAGE_KEYS.COMPANIES);
  const contacts = getData(STORAGE_KEYS.CONTACTS);
  
  const companySelect = document.getElementById('dealCompany');
  const contactSelect = document.getElementById('dealContact');
  
  companySelect.innerHTML = '<option value="">Select Company</option>' + 
    companies.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  
  contactSelect.innerHTML = '<option value="">Select Contact</option>' + 
    contacts.map(c => `<option value="${c.id}">${c.firstName} ${c.lastName}</option>`).join('');

  if (dealId) {
    title.textContent = 'Edit Deal';
    const deals = getData(STORAGE_KEYS.DEALS);
    const deal = deals.find(d => d.id === dealId);
    if (deal) {
      document.getElementById('dealName').value = deal.name || '';
      document.getElementById('dealCompany').value = deal.companyId || '';
      document.getElementById('dealContact').value = deal.contactId || '';
      document.getElementById('dealValue').value = deal.value || '';
      document.getElementById('dealStage').value = deal.stage || 'Prospecting';
      document.getElementById('dealCloseDate').value = deal.closeDate ? deal.closeDate.split('T')[0] : '';
      form.dataset.dealId = dealId;
    }
  } else {
    title.textContent = 'Add Deal';
    form.reset();
    delete form.dataset.dealId;
  }

  modal.classList.add('active');
};

window.saveDeal = function(e) {
  e.preventDefault();
  const form = document.getElementById('dealForm');
  const dealId = form.dataset.dealId;
  const deals = getData(STORAGE_KEYS.DEALS);
  const companies = getData(STORAGE_KEYS.COMPANIES);

  const companyId = document.getElementById('dealCompany').value;
  const company = companies.find(c => c.id === companyId);

  const data = {
    name: document.getElementById('dealName').value,
    companyId: companyId,
    companyName: company ? company.name : '',
    contactId: document.getElementById('dealContact').value,
    value: document.getElementById('dealValue').value,
    stage: document.getElementById('dealStage').value,
    closeDate: document.getElementById('dealCloseDate').value
  };

  if (dealId) {
    const index = deals.findIndex(d => d.id === dealId);
    if (index !== -1) {
      deals[index] = { ...deals[index], ...data, updatedAt: new Date().toISOString() };
    }
  } else {
    deals.push({
      id: generateId(),
      ...data,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  setData(STORAGE_KEYS.DEALS, deals);
  closeModal('dealModal');
  loadDeals();
  if (document.getElementById('dashboard').classList.contains('active')) {
    loadDashboard();
  }
};

window.editDeal = function(id) {
  openDealModal(id);
};

window.deleteDeal = function(id) {
  if (confirm('Are you sure you want to delete this deal?')) {
    const deals = getData(STORAGE_KEYS.DEALS);
    const filtered = deals.filter(d => d.id !== id);
    setData(STORAGE_KEYS.DEALS, filtered);
    loadDeals();
    if (document.getElementById('dashboard').classList.contains('active')) {
      loadDashboard();
    }
  }
};

// ========== TASKS ==========
function loadTasks() {
  renderTasks(getData(STORAGE_KEYS.TASKS));
}

function renderTasks(tasks) {
  const list = document.getElementById('tasksList');
  list.innerHTML = tasks.length > 0
    ? tasks.map(task => `
        <div class="task-item">
          <input type="checkbox" class="task-checkbox" ${task.status === 'Completed' ? 'checked' : ''} 
                 onchange="toggleTaskStatus('${task.id}')">
          <div class="task-content">
            <div class="task-title">${task.title}</div>
            <div class="task-description">${task.description || ''}</div>
            <div class="task-meta">
              <span class="priority-badge priority-${(task.priority || 'medium').toLowerCase()}">${task.priority || 'Medium'}</span>
              <span>Status: ${task.status || 'Pending'}</span>
              ${task.dueDate ? `<span>Due: ${formatDate(task.dueDate)}</span>` : ''}
            </div>
          </div>
          <div class="action-buttons">
            <button class="btn-icon btn-edit" onclick="editTask('${task.id}')" title="Edit">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
            <button class="btn-icon btn-delete" onclick="deleteTask('${task.id}')" title="Delete">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      `).join('')
    : '<div class="empty-state">No tasks found</div>';
}

window.filterTasks = function(filter) {
  document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');

  const tasks = getData(STORAGE_KEYS.TASKS);
  let filtered = tasks;
  if (filter !== 'all') {
    filtered = tasks.filter(t => {
      if (filter === 'completed') return t.status === 'Completed';
      if (filter === 'pending') return t.status === 'Pending';
      if (filter === 'in-progress') return t.status === 'In Progress';
      return true;
    });
  }
  renderTasks(filtered);
};

window.openTaskModal = function(taskId = null) {
  const modal = document.getElementById('taskModal');
  const form = document.getElementById('taskForm');
  const title = document.getElementById('taskModalTitle');

  if (taskId) {
    title.textContent = 'Edit Task';
    const tasks = getData(STORAGE_KEYS.TASKS);
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      document.getElementById('taskTitle').value = task.title || '';
      document.getElementById('taskDescription').value = task.description || '';
      document.getElementById('taskPriority').value = task.priority || 'Medium';
      document.getElementById('taskStatus').value = task.status || 'Pending';
      document.getElementById('taskDueDate').value = task.dueDate ? task.dueDate.split('T')[0] : '';
      form.dataset.taskId = taskId;
    }
  } else {
    title.textContent = 'Add Task';
    form.reset();
    delete form.dataset.taskId;
  }

  modal.classList.add('active');
};

window.saveTask = function(e) {
  e.preventDefault();
  const form = document.getElementById('taskForm');
  const taskId = form.dataset.taskId;
  const tasks = getData(STORAGE_KEYS.TASKS);

  const data = {
    title: document.getElementById('taskTitle').value,
    description: document.getElementById('taskDescription').value,
    priority: document.getElementById('taskPriority').value,
    status: document.getElementById('taskStatus').value,
    dueDate: document.getElementById('taskDueDate').value
  };

  if (taskId) {
    const index = tasks.findIndex(t => t.id === taskId);
    if (index !== -1) {
      tasks[index] = { ...tasks[index], ...data, updatedAt: new Date().toISOString() };
    }
  } else {
    tasks.push({
      id: generateId(),
      ...data,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  }

  setData(STORAGE_KEYS.TASKS, tasks);
  closeModal('taskModal');
  loadTasks();
  if (document.getElementById('dashboard').classList.contains('active')) {
    loadDashboard();
  }
};

window.editTask = function(id) {
  openTaskModal(id);
};

window.toggleTaskStatus = function(id) {
  const tasks = getData(STORAGE_KEYS.TASKS);
  const task = tasks.find(t => t.id === id);
  if (task) {
    const newStatus = task.status === 'Completed' ? 'Pending' : 'Completed';
    const index = tasks.findIndex(t => t.id === id);
    if (index !== -1) {
      tasks[index] = { ...tasks[index], status: newStatus, updatedAt: new Date().toISOString() };
      setData(STORAGE_KEYS.TASKS, tasks);
      loadTasks();
      if (document.getElementById('dashboard').classList.contains('active')) {
        loadDashboard();
      }
    }
  }
};

window.deleteTask = function(id) {
  if (confirm('Are you sure you want to delete this task?')) {
    const tasks = getData(STORAGE_KEYS.TASKS);
    const filtered = tasks.filter(t => t.id !== id);
    setData(STORAGE_KEYS.TASKS, filtered);
    loadTasks();
    if (document.getElementById('dashboard').classList.contains('active')) {
      loadDashboard();
    }
  }
};

// ========== ACTIVITIES ==========
function loadActivities() {
  const activities = getData(STORAGE_KEYS.ACTIVITIES);
  const list = document.getElementById('activitiesList');
  list.innerHTML = activities.length > 0
    ? activities.map(activity => `
        <div class="activity-item">
          <div class="activity-icon" style="background: #dbeafe; color: #2563eb;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
          </div>
          <div class="activity-content">
            <div class="activity-header">
              <span class="activity-subject">${activity.subject}</span>
              <span class="activity-time">${formatTimeAgo(activity.createdAt)}</span>
            </div>
            <div class="activity-description">${activity.description || ''}</div>
          </div>
        </div>
      `).join('')
    : '<div class="empty-state">No activities found</div>';
}

window.openActivityModal = function() {
  document.getElementById('activityModal').classList.add('active');
};

window.saveActivity = function(e) {
  e.preventDefault();
  const form = document.getElementById('activityForm');
  const activities = getData(STORAGE_KEYS.ACTIVITIES);

  const data = {
    type: document.getElementById('activityType').value,
    subject: document.getElementById('activitySubject').value,
    description: document.getElementById('activityDescription').value,
    related: document.getElementById('activityRelated').value
  };

  activities.unshift({
    id: generateId(),
    ...data,
    createdBy: currentUser.id,
    createdAt: new Date().toISOString()
  });

  setData(STORAGE_KEYS.ACTIVITIES, activities);
  closeModal('activityModal');
  form.reset();
  loadActivities();
  if (document.getElementById('dashboard').classList.contains('active')) {
    loadDashboard();
  }
};

// ========== REPORTS ==========
function loadReports() {
  const deals = getData(STORAGE_KEYS.DEALS);
  const companies = getData(STORAGE_KEYS.COMPANIES);
  const activities = getData(STORAGE_KEYS.ACTIVITIES);
  
  const totalRevenue = deals.reduce((sum, deal) => sum + (parseFloat(deal.value) || 0), 0);
  const wonDeals = deals.filter(d => d.stage === 'Won').length;
  const conversionRate = deals.length > 0 ? ((wonDeals / deals.length) * 100).toFixed(1) : 0;

  document.getElementById('revenueChart').innerHTML = `
    <div style="padding: 20px; text-align: center; color: #64748b;">
      Revenue visualization
      <br><small>Total: $${formatNumber(totalRevenue)}</small>
    </div>
  `;

  document.getElementById('conversionChart').innerHTML = `
    <div style="padding: 20px; text-align: center;">
      <div style="font-size: 48px; font-weight: 700; color: #2563eb; margin-bottom: 8px;">
        ${conversionRate}%
      </div>
      <div style="color: #64748b; font-size: 14px;">
        ${wonDeals} of ${deals.length} deals won
      </div>
    </div>
  `;

  if (companies.length > 0) {
    const topCompanies = companies.slice(0, 5);
    document.getElementById('topCompanies').innerHTML = topCompanies.map(c => `
      <div style="padding: 12px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between;">
        <span>${c.name}</span>
        <span style="font-weight: 600;">${c.revenue ? '$' + formatNumber(c.revenue) : '-'}</span>
      </div>
    `).join('');
  } else {
    document.getElementById('topCompanies').innerHTML = '<div class="empty-state">No companies</div>';
  }

  if (activities.length > 0) {
    const summary = activities.reduce((acc, a) => {
      acc[a.type] = (acc[a.type] || 0) + 1;
      return acc;
    }, {});

    document.getElementById('activitySummary').innerHTML = Object.entries(summary).map(([type, count]) => `
      <div style="padding: 12px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between;">
        <span>${type}</span>
        <span style="font-weight: 600;">${count}</span>
      </div>
    `).join('');
  } else {
    document.getElementById('activitySummary').innerHTML = '<div class="empty-state">No activities</div>';
  }
}

// ========== MODAL HELPERS ==========
window.closeModal = function(modalId) {
  document.getElementById(modalId).classList.remove('active');
};

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.classList.remove('active');
    });
  }
});

// ========== UTILITY FUNCTIONS ==========
function formatNumber(num) {
  return new Intl.NumberFormat('en-US').format(num);
}

function formatDate(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatTimeAgo(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  const now = new Date();
  const diff = now - date;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  return formatDate(dateString);
}






