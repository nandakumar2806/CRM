# Troubleshooting Guide

## ✅ Server Status: RUNNING

The server is currently running and responding correctly on port 3000.

## If you see "ERR_CONNECTION_REFUSED"

### Step 1: Verify Server is Running
1. Open a terminal/command prompt
2. Navigate to the project folder: `cd litnetX`
3. Run: `node server.js`
4. You should see: `CRM Server running on http://localhost:3000`

### Step 2: Check Port 3000
Run this command to check if port 3000 is in use:
```bash
netstat -ano | findstr :3000
```

If you see output, the server is running. If not, start the server.

### Step 3: Restart the Server
**Option A: Use the batch file**
- Double-click `RESTART-SERVER.bat`

**Option B: Manual restart**
1. Stop any running Node processes:
   ```bash
   taskkill /F /IM node.exe
   ```
2. Start the server:
   ```bash
   node server.js
   ```

### Step 4: Browser Troubleshooting
1. **Clear browser cache**: Press `Ctrl+Shift+Delete` and clear cached files
2. **Hard refresh**: Press `Ctrl+F5` or `Ctrl+Shift+R`
3. **Try different browser**: Chrome, Firefox, Edge
4. **Try incognito/private mode**
5. **Check browser console**: Press `F12` → Console tab for errors

### Step 5: Check Firewall
Windows Firewall might be blocking Node.js:
1. Open Windows Defender Firewall
2. Allow Node.js through the firewall
3. Or temporarily disable firewall to test

### Step 6: Try Alternative URLs
- `http://127.0.0.1:3000`
- `http://localhost:3000`
- `http://0.0.0.0:3000`

## Quick Test

1. Open browser
2. Go to: `http://localhost:3000`
3. You should see a purple gradient background with a white login box
4. Login with:
   - Username: `admin`
   - Password: `admin123`

## Common Issues

### Issue: Blank Page
**Solution**: 
- Open browser console (F12)
- Check for JavaScript errors
- Verify CSS is loading (Network tab)

### Issue: "Cannot GET /"
**Solution**: 
- Server might not be running
- Restart the server
- Check server.js is in the root directory

### Issue: Port Already in Use
**Solution**:
```bash
# Find process using port 3000
netstat -ano | findstr :3000

# Kill the process (replace PID with actual process ID)
taskkill /F /PID <PID>
```

### Issue: Module Not Found
**Solution**:
```bash
npm install
```

## Still Having Issues?

1. Check server terminal for error messages
2. Check browser console (F12) for errors
3. Verify all files are in place:
   - `server.js` (root)
   - `public/index.html`
   - `public/style.css`
   - `public/script.js`
   - `package.json`

## Server Commands

**Start server:**
```bash
node server.js
```

**Start with auto-reload (if nodemon installed):**
```bash
npm run dev
```

**Check if server is running:**
```bash
netstat -ano | findstr :3000
```

**Stop server:**
- Press `Ctrl+C` in the terminal where server is running
- Or: `taskkill /F /IM node.exe`






