Write-Host "Starting CRM Server..." -ForegroundColor Green
Write-Host ""
node server.js

